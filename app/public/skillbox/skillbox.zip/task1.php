<?php
$result1 = [
    'author' => [
        'fio' => 'Иванов Иван Иванович',
        'email' => 'invan@yandex.ru',
    ],
    'book' => [
        'book_name' => 'Старик и рыбка',
        'author_email' => 'invan@yandex.ru',
    ],
];
print_r($result1);
