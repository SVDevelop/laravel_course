<?php
$result3 = [
	'authors' => [
		'Stiven@mail.com' => ['Стивен Кинг', '21 сентября 1947'],
		'cherchel.uitson@mail.com' => ['Уинстон Черчилль', '30 ноября 1874'],
		'uoker.elis@mail.com' => ['Элис Уокер', '9 февраля 1944'],
		'Strechi@mail.com' => ['Литтон Стрейчи', '1 марта 1880']
	], 
	'books' => [
		['Кэрри', 'Stiven@mail.com'],
		['Вторая мировая война', 'cherchel.uitson@mail.com'],
		['Цвет пурпурный', 'uoker.elis@mail.com'],
		['Знаменитые викторианцы', 'Strechi@mail.com']
	]
];
foreach ($result3['authors'] as $mail => $value) :

	$array = array_filter($result3['books'], function ($array)
	{
		global $mail;
		return $array[1] === $mail;
	});
?>
	<p>
		Книга "<?=array_values($array)[0][0];?>", ее написал <?=$value[0];?> <?=$value[1];?> (<?=$mail;?>)
	</p>
<?php endforeach ?>

<br>
<br>
<?php
shuffle($result3['books']);
foreach ($result3['authors'] as $mail => $value) :

	$array = array_filter($result3['books'], function ($array)
	{
		global $mail;
		return $array[1] === $mail;
	});
?>
	<p>
		Книга "<?=array_values($array)[0][0];?>", ее написал <?=$value[0];?> <?=$value[1];?> (<?=$mail;?>)
	</p>
<?php endforeach ?>