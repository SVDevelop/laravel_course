<?php
$result1 = [
	'author' => ['fio', 'email'], 
	'book' => ['book_name', 'author_email']
];
print_r($result1);
?>
