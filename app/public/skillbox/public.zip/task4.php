<?php 
$title = "Заголовок";
$red = (bool) rand(0, 1);
$classStyle = "class='red'";

$result3 = [
	'authors' => [
		'Stiven@mail.com' => ['Стивен Кинг', '21 сентября 1947'],
		'cherchel.uitson@mail.com' => ['Уинстон Черчилль', '30 ноября 1874'],
		'uoker.elis@mail.com' => ['Элис Уокер', '9 февраля 1944'],
		'Strechi@mail.com' => ['Литтон Стрейчи', '1 марта 1880']
	], 
	'books' => [
		['Кэрри', 'Stiven@mail.com'],
		['Вторая мировая война', 'cherchel.uitson@mail.com'],
		['Цвет пурпурный', 'uoker.elis@mail.com'],
		['Знаменитые викторианцы', 'Strechi@mail.com']
	]
];
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?=$title;?></title>
    <style type="text/css">.red {color: red;}</style>
</head>
<body>
	<!-- if red true h1 class=”red” -->
<h1 <?=($red === false)? "": $classStyle;?>>Заголовок</h1>
<div>Авторов на портале <<?=count($result3['authors'])?>></div>
<!-- Выведите все книги -->

<?php 
foreach ($result3['authors'] as $mail => $value) :
	// получаем email из первого массива
	
	$array = array_filter($result3['books'], function ($array)
	{
		global $mail;
		return $array[1] === $mail;
	});
?>
	<p>
		Книга "<?=array_values($array)[0][0];?>", ее написал <?=$value[0];?> <?=$value[1];?> (<?=$mail;?>)
	</p>
<?php endforeach ?>

</body>
</html>
