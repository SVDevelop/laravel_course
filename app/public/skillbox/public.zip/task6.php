<?php 
$rand_number = rand(1, 1000000);

function countStudent ($num) {
    //Оставляем две последние цифры от $num
	$number = substr($num, -2);
	if($number > 20 and $number < 22)
	{
		$term = "";
	}
	else
	{ 
		$number = substr($number, -1);
		if($number == 0) {$term = "ов";}
		if($number == 1 ) {$term = "";}
		if($number > 1 ) {$term = "а";}
		if($number > 4 ) {$term = "ов";}
	}
	echo  'на учебе:' .$num.' студент'.$term;
};
countStudent($rand_number);
 ?>