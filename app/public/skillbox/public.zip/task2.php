<?php
$result2 = [
	'authors' => [
		['Стивен Кинг', 'Stiven@mail.com'],
		['Уинстон Черчилль', 'cherchel.uitson@mail.com'],
		['Элис Уокер', 'uoker.elis@mail.com'],
		['Литтон Стрейчи', 'Strechi@mail.com']
	], 
	'books' => [
		['Кэрри', 'Stiven@mail.com'],
		['Вторая мировая война', 'cherchel.uitson@mail.com'],
		['Цвет пурпурный', 'uoker.elis@mail.com'],
		['Знаменитые викторианцы', 'Strechi@mail.com']
	]
];
?>
<pre>
<?=print_r($result2);?>
</pre>