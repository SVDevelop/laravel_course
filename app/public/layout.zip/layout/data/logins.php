<?php
$logins = ['admin', 'user', 'root'];
?>
