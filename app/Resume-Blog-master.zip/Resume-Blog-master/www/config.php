<?php 

/* параметры подключения к БД */
define('DB_HOST', 'localhost');
define('DB_NAME', 'WD03-project-kovtun');
define('DB_USER', 'root');
define('DB_PASS', '');

/* site settings for emails */
define('SITE_NAME', 'Личный сайт Людмилы Ковтун');
define('SITE_EMAIL', 'info@webdev03.com');
define('ADMIN_EMAIL', 'laudylim@yandex.ru');


?>