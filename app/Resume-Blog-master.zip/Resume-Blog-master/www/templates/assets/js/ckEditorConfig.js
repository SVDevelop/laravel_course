CKEDITOR.editorConfig = function( config ) {
	config.uiColor = '#b1bfc7';
	config.allowedContent = true;
	config.disableNativeSpellChecker = false;
	config.bodyClass = 'user-content';
};